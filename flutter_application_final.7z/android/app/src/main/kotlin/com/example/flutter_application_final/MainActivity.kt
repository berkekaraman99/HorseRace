package com.example.flutter_application_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
