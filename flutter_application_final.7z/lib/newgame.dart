import 'package:flutter/material.dart';
import 'package:flutter_application_final/gamestate.dart';

class NewGame extends StatelessWidget {
  NewGame({super.key});
  Map<int, String> horseMap = {
    0: "At 1",
    1: "At 2",
    2: "At 3",
    3: "At 4",
    4: "At 5",
  };
  Map<int, Color> colors = {
    0: Colors.red,
    1: Colors.orange,
    2: Colors.green,
    3: Colors.blue,
    4: Colors.purple,
  };

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: horseMap.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return Column(
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const GameState()));
                  },
                  child: Text(
                    horseMap[index].toString(),
                    style: TextStyle(fontSize: 24.0, color: colors[index]),
                  )),
              const SizedBox(
                height: 10.0,
              ),
            ],
          );
        });
  }
}
