// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:ffi';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';

class GameState extends StatefulWidget {
  const GameState({super.key});

  @override
  State<GameState> createState() => _GameStateState();
}

class _GameStateState extends State<GameState> {
  List<double> aniConWidth =
      List.generate(5, (index) => Horses.horses[index].location ?? 0);
  // ! initState
  @override
  void initState() {
    super.initState();
    _func();
  }

  // ? kontrol fonksiyonu
  Future<void> _func() async {
    //,lk 100 ms 2
    //100 ms
    while (!(Horses.horses[0].isFinished ?? false) &&
        !(Horses.horses[1].isFinished ?? false) &&
        !(Horses.horses[2].isFinished ?? false) &&
        !(Horses.horses[3].isFinished ?? false) &&
        !(Horses.horses[4].isFinished ?? false)) {
      print("Döngü başı");
      for (var horse in Horses.horses) {
        if ((horse.location ?? 0) < 100) {
          print("Hesaplamalar");
          horse.calcuteMove();
          horse.updateLocation();
          setState(() {
            aniConWidth[horse.index!] += horse.location ?? 0;
          });
        } else {
          horse.isFinished = true;
        }
        Future.delayed(const Duration(microseconds: 100));
        print(horse.isFinished);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final double _width = MediaQuery.of(context).size.width;
    final double _height = MediaQuery.of(context).size.height;
    const double _topPadding = 50;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 8.0),
        child: Column(
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(16.0))),
              height: _height * 0.85,
              width: _width,
              child: Stack(
                children: [
                  AnimatedPositioned(
                    duration: const Duration(milliseconds: 500),
                    left: 0,
                    child: AnimatedContainer(
                      decoration: const BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.all(Radius.circular(8.0))),
                      height: 40,
                      width: aniConWidth[0],
                      margin: const EdgeInsets.all(8.0),
                      duration: const Duration(milliseconds: 500),
                    ),
                  ),
                  Positioned(
                    top: _topPadding,
                    left: 0,
                    child: AnimatedContainer(
                      decoration: const BoxDecoration(
                          color: Colors.orange,
                          borderRadius: BorderRadius.all(Radius.circular(8.0))),
                      height: 40,
                      width: aniConWidth[1],
                      margin: const EdgeInsets.all(8.0),
                      duration: const Duration(milliseconds: 500),
                    ),
                  ),
                  Positioned(
                    top: _topPadding * 2,
                    left: 0,
                    child: AnimatedContainer(
                      decoration: const BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.all(Radius.circular(8.0))),
                      height: 40,
                      width: aniConWidth[2],
                      margin: const EdgeInsets.all(8.0),
                      duration: const Duration(milliseconds: 500),
                    ),
                  ),
                  Positioned(
                    top: _topPadding * 3,
                    left: 0,
                    child: AnimatedContainer(
                      decoration: const BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.all(Radius.circular(8.0))),
                      height: 40,
                      width: aniConWidth[3],
                      margin: const EdgeInsets.all(8.0),
                      duration: const Duration(milliseconds: 500),
                    ),
                  ),
                  Positioned(
                    top: _topPadding * 4,
                    left: 0,
                    child: AnimatedContainer(
                      decoration: const BoxDecoration(
                          color: Colors.purple,
                          borderRadius: BorderRadius.all(Radius.circular(8.0))),
                      height: 40,
                      width: aniConWidth[4],
                      margin: const EdgeInsets.all(8.0),
                      duration: const Duration(milliseconds: 500),
                    ),
                  ),
                ],
              ),
            ),
            ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Geri Dön")),
          ],
        ),
      ),
    );
  }
}

class Horses {
  static List<Horse> horses = [
    Horse(name: 'At 1', location: 10, move: 0, isFinished: false, index: 0),
    Horse(name: 'At 2', location: 10, move: 0, isFinished: false, index: 1),
    Horse(name: 'At 3', location: 10, move: 0, isFinished: false, index: 2),
    Horse(name: 'At 4', location: 10, move: 0, isFinished: false, index: 3),
    Horse(name: 'At 5', location: 10, move: 0, isFinished: false, index: 4),
  ];
}

class Horse {
  String? name;
  double? location;
  double? move;
  bool? isFinished;
  int? index;
  Horse({this.name, this.location, this.move, this.isFinished, this.index});

  Future<void> calcuteMove() async {
    move = Random().nextDouble() * 5;
  }

  Future<void> updateLocation() async {
    location = (location ?? 0) + (move ?? 0);
  }

  Future<void> updateIsFinished() async {
    isFinished = true;
  }
}
