import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class Settings extends StatelessWidget {
  const Settings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Ayarlar"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical:24.0, horizontal: 16.0),
        child: Column(
          children: [
            Text("Test"),
            SizedBox(height: 40,),
            Text("Test"),
            Text("Test"),
            Text("Test"),
            Text("Test"),
            Text("Test"),
            Text("Test"),
          ],
        ),
      ),
      backgroundColor: ThemeData.dark().primaryColor,
    );
  }
}