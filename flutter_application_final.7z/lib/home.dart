import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_application_final/newgame.dart';
import 'package:flutter_application_final/settings.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/mobileBackground.jpg'),
                fit: BoxFit.cover)),
        child: Padding(
          padding: const EdgeInsets.only(top: 80.0, bottom: 64.0),
          child: Center(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Horse Race",
                style: TextStyle(fontSize: 36.0, color: Colors.white),
              ),
              Column(
                children: [
                  TextButton(
                      onPressed: () {
                        // Navigator.push(context,
                        //     MaterialPageRoute(builder: (context) => NewGame()));
                        showModalBottomSheet(
                            backgroundColor: Colors.transparent,
                            isDismissible: false,
                            context: context,
                            builder: (BuildContext context) {
                              return _GameBottomSheet();
                            });
                      },
                      child: const Text(
                        "Yeni Oyuna Başla",
                        style: TextStyle(fontSize: 20.0),
                      )),
                  SizedBox(
                    height: 10,
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Settings()));
                      },
                      child: const Text(
                        "Ayarlar",
                        style: TextStyle(fontSize: 20.0),
                      )),
                  SizedBox(
                    height: 10,
                  ),
                  TextButton(
                      onPressed: () {
                        exit(0);
                      },
                      child: const Text(
                        "Çıkış",
                        style: TextStyle(fontSize: 20.0),
                      )),
                ],
              ),
            ],
          )),
        ),
      ),
    );
  }
}

class _GameBottomSheet extends StatefulWidget {
  const _GameBottomSheet({
    Key? key,
  }) : super(key: key);

  @override
  State<_GameBottomSheet> createState() => _GameBottomSheetState();
}

class _GameBottomSheetState extends State<_GameBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.grey.shade900,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16.0))),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 8.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Haydi başlayalım",
                  style: TextStyle(fontSize: 36.0, color: Colors.white)),
              const SizedBox(
                height: 16.0,
              ),
              const Text("Atınızı Seçiniz",
                  style: TextStyle(fontSize: 28.0, color: Colors.white)),
              Expanded(child: Center(child: NewGame())),
              Row(
                children: [
                  ElevatedButton.icon(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back),
                      label: const Text("Geri Dön"))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
