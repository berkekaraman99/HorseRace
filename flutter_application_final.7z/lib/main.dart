import 'package:flutter/material.dart';
import 'package:flutter_application_final/home.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});
  ThemeData darkThemeData = ThemeData.dark();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: Colors.black,
        textTheme: ThemeData.dark().textTheme
      ),
      home: const MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}
